function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
var start = new Date().getTime();
function move() {
    var left = Math.random() * (window.innerWidth - 200);
    var top = Math.random() * (window.innerHeight - 200);
    var wh = (Math.random() * 200) + 100;
    var box = document.getElementById("box");
    box.style.left = left + 'px';
    box.style.top = top + 'px';
    box.style.width = wh + 'px';
    box.style.height = wh + 'px';
    box.style.display = "block";
    box.style.backgroundColor = getRandomColor();
    start = new Date().getTime();
}
move();

document.getElementById("box").onclick = function () {
    document.getElementById("box").style.display = "none";
    var end = new Date().getTime();
    var timeTaken = (end - start) / 1000;
    //alert("Your time is: " + timeTaken + "s");
    move();
}